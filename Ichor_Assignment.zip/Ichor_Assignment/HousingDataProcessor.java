// Importing required classes from Apache Commons CSV for handling CSV parsing and writing.
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;

// Importing the Logger class from Apache Log4j for logging events and errors.
import org.apache.log4j.Logger;

// Importing standard Java classes for handling I/O and utility functions.
import java.io.*;
import java.util.*;

// Main class that processes housing data from a CSV file.
public class HousingDataProcessor {

    // Initializing a Logger for logging information, warnings, and errors.
    private static final Logger logger = Logger.getLogger(HousingDataProcessor.class);

    // Inner class to represent data related to a city, including its name, 
    // oldest home value, newest home value, and the percentage change between them.
    private static class CityData {
        String name; // Name of the city
        double oldestValue; // Oldest recorded home value
        double newestValue; // Newest recorded home value
        double percentageChange; // Percentage change from oldest to newest value

        // Constructor to initialize the city data and calculate the percentage change.
        CityData(String name, double oldestValue, double newestValue) {
            this.name = name;
            this.oldestValue = oldestValue;
            this.newestValue = newestValue;
            this.percentageChange = calculatePercentageChange(oldestValue, newestValue);
        }

        // Method to calculate the percentage change between two values.
        // Handles the case where the oldest value is zero by logging a warning
        // and returning a positive infinity percentage change.
        private double calculatePercentageChange(double oldValue, double newValue) {
            if (oldValue == 0) {
                logger.warn("Old value is zero for city " + name + ", setting percentage change to infinity");
                return Double.POSITIVE_INFINITY;
            }
            return ((newValue - oldValue) / oldValue) * 100;
        }
    }

    // Main method that serves as the entry point of the program.
    public static void main(String[] args) {
        // Checking if the correct number of command-line arguments are provided.
        // If not, log an error and exit the program.
        if (args.length != 2) {
            logger.error("Usage: java HousingDataProcessor <inputFile> <outputFile>");
            System.exit(1);
        }

        // Assigning command-line arguments to variables for input and output file paths.
        String inputFile = args[0];
        String outputFile = args[1];

        // Logging the start of the processing, including the input file path.
        logger.info("Starting processing with input file: " + inputFile);

        // Initializing a list to store the processed city data.
        List<CityData> cityDataList = new ArrayList<>();

        try {
            // Processing the input file to extract city data.
            cityDataList = processInputFile(inputFile);
            // If no valid data is found, log a warning and exit the program.
            if (cityDataList.isEmpty()) {
                logger.warn("No valid city data found in the input file.");
                System.exit(1);
            }
            // Writing the processed data to the output file.
            writeCitiesToOutput(cityDataList, outputFile);
        } catch (FileNotFoundException e) {
            // Log an error if the input file is not found and exit the program.
            logger.error("Input file not found: " + inputFile, e);
            System.exit(1);
        } catch (IOException e) {
            // Log an error if there's an I/O issue during processing and exit the program.
            logger.error("Error processing files: " + e.getMessage(), e);
            System.exit(1);
        }

        // Log the completion of the processing and the location of the output file.
        logger.info("Processing complete. Results written to " + outputFile);
    }

    // Method to process the input CSV file and extract the necessary data for each city.
    public static List<CityData> processInputFile(String inputFile) throws IOException {
        // List to store the city data after processing.
        List<CityData> cityDataList = new ArrayList<>();

        // Using a try-with-resources block to ensure resources are closed after use.
        try (Reader reader = new FileReader(inputFile);
             // Setting up the CSV parser with the appropriate format.
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.builder()
                                                      .setHeader() // Treat the first row as headers.
                                                      .setSkipHeaderRecord(true) // Skip the header row during parsing.
                                                      .build())) {

            // Iterating over each record (row) in the CSV file.
            for (CSVRecord record : csvParser) {
                String cityName = record.get("RegionName"); // Extracting the city name.
                double oldestValue = 0; // Initializing the oldest value.
                double newestValue = 0; // Initializing the newest value.

                // Loop through the columns to find the oldest and newest non-empty values.
                for (int i = 8; i < record.size(); i++) { // Starting from column index 8 (assumed to be the first data column).
                    String value = record.get(i); // Extracting the value at the current column.
                    if (!value.isEmpty()) { // If the value is not empty:
                        try {
                            double doubleValue = Double.parseDouble(value); // Convert the string to a double.
                            if (oldestValue == 0) oldestValue = doubleValue; // Set the first non-zero value as the oldest.
                            newestValue = doubleValue; // Update the newest value.
                        } catch (NumberFormatException e) {
                            // Log a warning if the value cannot be parsed to a double.
                            logger.warn("Invalid number format for city " + cityName + " at index " + i);
                        }
                    }
                }

                // Add the city data to the list only if both oldest and newest values are valid.
                if (oldestValue != 0 && newestValue != 0) {
                    cityDataList.add(new CityData(cityName, oldestValue, newestValue));
                } else {
                    // Log a warning if the data is insufficient and skip this city.
                    logger.warn("Skipping city " + cityName + " due to missing data");
                }
            }
        }

        // Return the list of city data after processing.
        return cityDataList;
    }

    // Method to write the processed city data to the output CSV file.
    public static void writeCitiesToOutput(List<CityData> cityDataList, String outputFile) throws IOException {
        // Sort the city data list by percentage change in ascending order.
        cityDataList.sort(Comparator.comparingDouble(city -> city.percentageChange));

        // Get the city with the smallest percentage change.
        CityData minChangeCity = cityDataList.get(0);
        // Get the city with the largest percentage change.
        CityData maxChangeCity = cityDataList.get(cityDataList.size() - 1);

        // Using a try-with-resources block to ensure the writer and CSV printer are closed after use.
        try (Writer writer = new FileWriter(outputFile);
             CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT.builder()
                                                      .setHeader("CityName", "OldestHomeValue", "NewestHomeValue", "PercentageChange") // Set the output CSV headers.
                                                      .build())) {

            // Write the city with the largest percentage change to the output file.
            csvPrinter.printRecord(maxChangeCity.name, 
                                   String.format("%.2f", maxChangeCity.oldestValue), 
                                   String.format("%.2f", maxChangeCity.newestValue), 
                                   String.format("+%.2f%%", maxChangeCity.percentageChange));

            // Write the city with the smallest percentage change to the output file.
            csvPrinter.printRecord(minChangeCity.name, 
                                   String.format("%.2f", minChangeCity.oldestValue), 
                                   String.format("%.2f", minChangeCity.newestValue), 
                                   String.format("%.2f%%", minChangeCity.percentageChange));
        }
    }
}
