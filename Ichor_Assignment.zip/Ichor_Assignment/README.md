Housing Data Processor
Overview
This project processes housing data from a CSV file, calculates percentage changes in home values over time for various cities, and identifies the cities with the largest and smallest percentage increases. The results are written to an output CSV file.
1: Setup
    Prerequisites
    * Java Development Kit (JDK) 11 or later: Ensure Java is installed on your system.
    * Apache Commons CSV Library: For efficient CSV parsing.
    * Apache Log4j: For logging important events, warnings, and errors.

2: Installation
    1. Clone the Repository:
        * If you are using version control (e.g., Git), clone the repository to your local machine.
        * Command:bashCopy code  git clone <repository-url> 
    2. Set Up Dependencies:
        * Download the necessary JAR files:
            * commons-csv-1.11.0.jar
            * commons-io-2.16.1.jar
            * commons-codec-1.17.1.jar
            * log4j-1.2.17.jar
        * Place these JAR files in the project directory or a lib directory.
3: Data Ingestion
    The program ingests a large CSV file containing housing data. Apache Commons CSV is used to efficiently parse the file and extract relevant columns such as RegionName and home value columns.
    Data Ingestion Steps:
    1. CSV Parsing:
        * The program reads the input CSV file using Apache Commons CSV, with the first row treated as headers.
        * It iterates through each row to extract city names and their corresponding home values over time.
    2. Error Handling:
        * Any issues during data parsing (e.g., missing values, incorrect formats) are logged, and the program continues processing the rest of the file.
    4: Data Processing
    Key Processing Steps:
    1. Extract Relevant Columns:
        * Extract RegionName (city names) and home values for each month.
    2. Determine Oldest and Newest Home Values:
        * Identify the earliest and latest non-empty home values for each city.
    3. Calculate Percentage Change:
        * Calculate the percentage change in home values from the oldest to the newest value.
    4. Identify Extremes:
        * Determine the cities with the largest and smallest percentage increases.
4: Scalability
    Considerations:
    * The current solution is designed to handle large datasets efficiently using Apache Commons CSV.
    * For even larger datasets, consider:
        * Distributed Processing: Use frameworks like Apache Spark to handle data in parallel.
        * Data Partitioning: Split the dataset into manageable chunks and process them independently.
5: Output Generation
    Output Details:
    * Output CSV: The results are written to an output CSV file with the following columns:
        * CityName: Name of the city.
        * OldestHomeValue: The oldest home value recorded.
        * NewestHomeValue: The newest home value recorded.
        * PercentageChange: The percentage change in home values.
    * Logging: The program logs the start and end of processing, any warnings, and errors.
6: Testing
    Unit Testing:
    * Test Cases: Unit tests have been written for key functions, such as calculating percentage changes and processing input files.
    * Test Data: A small test dataset (test_input.csv) is used to verify correctness before running the program on the full dataset.
    Running Tests:
    * To run the tests, use a testing framework like JUnit, integrated into your development environment.
7: Documentation
Comments:
    * The code is thoroughly commented, with explanations for each major section and method.
    README:
    * This README provides all the necessary information to run the solution, including setup, dependencies, and usage instructions.
8: Optimization
    Performance:
    * The code has been optimized for performance, especially when dealing with large datasets.
    * Memory usage has been considered, and efficient data structures are used to manage the data.
    Future Optimization:
    * Profiling: Additional profiling could be performed to identify and optimize any bottlenecks.
    * Parallel Processing: For very large datasets, consider parallelizing parts of the code.
9: Error Handling
    Implementation:
    * Exception Handling: The code catches and handles exceptions like FileNotFoundException and IOException.
    * Logging: Errors are logged with meaningful messages, and the program exits gracefully in case of critical issues.
    Robustness:
    * The program is designed to continue processing even if some data is malformed or missing, logging any issues encountered.
10: Final Steps
    Review:
        * The code has been reviewed for clarity, efficiency, and adherence to best practices.
        Testing on Full Dataset:
        * The solution has been tested on the provided dataset to ensure it works correctly.

11: Logging Setup:

The code uses Logger from Apache Log4j to log messages at various levels (INFO, WARN, ERROR). This is crucial for monitoring and debugging.

12: CityData Class:
The CityData class represents the data for each city, including its name, oldest and newest home values, and the percentage change in home values.
The class includes a method to calculate the percentage change, handling special cases like zero values.

13: Main Method:
The main method processes command-line arguments to accept the input and output file paths.
It logs the start and completion of processing, handles file not found errors, and general I/O exceptions.

14: Data Processing (processInputFile):
    The processInputFile method reads and processes the input CSV file.
    It extracts city names and home values, determines the oldest and newest values, and stores this data in a list of CityData objects.
    The method includes error handling for invalid number formats and logs warnings when data is incomplete.
    Output Generation (writeCitiesToOutput):
    The writeCitiesToOutput method writes the processed data to an output CSV file.
    It sorts the cities by their percentage change and then writes the city with the largest and smallest percentage changes to the file.